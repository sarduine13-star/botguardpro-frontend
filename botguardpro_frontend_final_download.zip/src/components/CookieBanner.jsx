import React from 'react';

// Simple cookie consent banner. Displays at the bottom of the screen
// until the user clicks the Accept button. Consent state is stored in
// localStorage so the banner only appears once per user.
export default function CookieBanner() {
  // If consent has already been given, don't render anything
  if (typeof window !== 'undefined' && localStorage.getItem('cookiesAccepted') === 'true') {
    return null;
  }

  const accept = () => {
    localStorage.setItem('cookiesAccepted', 'true');
    // Trigger a re-render (noop component state) by forcing a state update
    // For simplicity here we use location.reload to remove the banner
    window.location.reload();
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#111',
        color: '#fff',
        padding: 10,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        zIndex: 9999
      }}
    >
      <span>We use cookies to improve BotGuard Pro.</span>
      <button
        onClick={accept}
        style={{ padding: '6px 12px', cursor: 'pointer' }}
      >
        Accept
      </button>
    </div>
  );
}