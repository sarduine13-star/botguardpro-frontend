import React, { useState } from 'react';
import './shield.css';

// AnimatedShield provides a visual spinning shield animation. It accepts
// an onSpin callback which is invoked after the spin animation completes.
// The shield rotates multiple times and scales slightly for dramatic
// effect. Although not currently used in the App, it can be integrated
// with the SpinShield component to enhance the spinning experience.
export default function AnimatedShield({ onSpin }) {
  const [spinning, setSpinning] = useState(false);

  const doSpin = () => {
    if (spinning) return;
    setSpinning(true);
    const duration = 2600;
    setTimeout(() => {
      setSpinning(false);
      if (typeof onSpin === 'function') onSpin();
    }, duration);
  };

  return (
    <div className="shield-wrapper">
      <div className={`shield ${spinning ? 'spin' : ''}`}>
        <img src="/shield.png" alt="shield" />
      </div>
      <button onClick={doSpin} className="shield-btn">
        Spin Shield
      </button>
    </div>
  );
}