import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Displays live statistics about automations run and bots blocked.
// Pulls data from the backend /stats endpoint on mount.
export default function LiveCounter() {
  const [stats, setStats] = useState({ runs: 0, blocked: 0 });

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await axios.get(`${API}/stats`);
        setStats(data);
      } catch (err) {
        // In case of failure, leave stats unchanged
      }
    };
    load();
  }, []);

  return (
    <div className="card">
      <div>Automations run: {stats.runs}</div>
      <div>Bots blocked: {stats.blocked}</div>
    </div>
  );
}