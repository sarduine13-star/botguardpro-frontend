import React, { useState } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Email capture component. Displays a simple form asking for the user's
// email address. On submit it POSTs to the backend /lead endpoint and
// shows a confirmation message. Accepts email and setEmail props to
// control external state for spin shield logic.
export default function EmailCapture({ email, setEmail }) {
  const [msg, setMsg] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/lead`, { email });
      setMsg('Check your inbox for details.');
    } catch (err) {
      setMsg('Failed to submit email.');
    }
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', flexWrap: 'wrap' }}>
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@example.com"
        required
        style={{
          padding: '10px',
          flex: '1 1 70%',
          marginRight: '10px',
          borderRadius: '4px',
          border: '1px solid #ccc'
        }}
      />
      <button
        type="submit"
        style={{
          padding: '10px 20px',
          background: '#00d1ff',
          color: '#000',
          border: 'none',
          borderRadius: '4px',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}
      >
        Continue
      </button>
      {msg && <div style={{ width: '100%', marginTop: '8px' }}>{msg}</div>}
    </form>
  );
}