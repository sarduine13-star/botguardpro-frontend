import React, { useState } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// SpinShield component implements the gamified spin-to-win mechanism.
// Users get three spins per session. Each spin invokes the backend
// /spin endpoint, displays the reward text and decrements spins left.
// If the returned payload includes a checkout_url, the user is
// redirected automatically to Stripe for trial activation. Rewards
// expire after they leave the page.
export default function SpinShield({ email }) {
  const [spinsLeft, setSpinsLeft] = useState(3);
  const [msg, setMsg] = useState('');
  const [reward, setReward] = useState(null);
  const [loading, setLoading] = useState(false);

  const spin = async () => {
    if (!email) {
      setMsg('Enter email first');
      return;
    }
    if (spinsLeft <= 0) {
      setMsg('No spins left');
      return;
    }
    setLoading(true);
    try {
      const { data } = await axios.post(`${API}/spin`, { email });
      setSpinsLeft((prev) => prev - 1);
      setReward(data.reward);
      setMsg(data.message);
      if (data.checkout_url) {
        // Redirect to Stripe session if checkout_url is provided
        window.location.href = data.checkout_url;
      }
    } catch (err) {
      setMsg('Error spinning. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <h3 className="neon">Spin the Shield</h3>
      <button
        disabled={loading}
        onClick={spin}
        style={{
          padding: '12px 20px',
          background: '#00d1ff',
          borderRadius: '6px',
          border: 'none',
          color: '#000',
          fontWeight: 'bold',
          cursor: loading ? 'not-allowed' : 'pointer',
          boxShadow: '0 0 10px #00d1ff'
        }}
      >
        {loading ? 'Spinning...' : `Spin (${spinsLeft} left)`}
      </button>
      {reward && (
        <div style={{ marginTop: '10px', fontWeight: 'bold' }}>Reward: {reward}</div>
      )}
      {msg && <div style={{ marginTop: '8px' }}>{msg}</div>}
    </div>
  );
}