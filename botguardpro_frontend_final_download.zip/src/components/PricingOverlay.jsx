import React from 'react';
import './pricing.css';

// PricingOverlay renders a modal with BotGuard Pro subscription plans. It
// appears over a darkened backdrop when the `open` prop is true. Clicking
// the backdrop or the close button triggers the `onClose` callback. Plan
// cards include feature lists and placeholder buttons for selecting plans.
export default function PricingOverlay({ open, onClose }) {
  // Do not render anything if the modal is not open
  if (!open) return null;

  return (
    <div className="overlay-backdrop" onClick={onClose}>
      <div className="overlay-panel" onClick={(e) => e.stopPropagation()}>
        <h1 className="neon overlay-title">BotGuard Pro Plans</h1>
        <p className="overlay-sub">Choose the plan that protects your site best.</p>
        <div className="pricing-grid">
          {/* Starter plan */}
          <div className="pricing-card">
            <h2>Starter</h2>
            <p className="price">$9.99 / mo</p>
            <ul>
              <li>Basic Firewall</li>
              <li>Scrape Blocking</li>
              <li>Threat Reports</li>
            </ul>
            <button className="buy-btn">Select Starter</button>
          </div>
          {/* Business plan */}
          <div className="pricing-card highlight">
            <h2>Business</h2>
            <p className="price">$19.99 / mo</p>
            <ul>
              <li>All Starter Features</li>
              <li>Speed Boost Layer</li>
              <li>Traffic Analytics</li>
              <li>Smart Threat Scanning</li>
            </ul>
            <button className="buy-btn">Select Business</button>
          </div>
          {/* Pro plan */}
          <div className="pricing-card">
            <h2>Pro</h2>
            <p className="price">$34.99 / mo</p>
            <ul>
              <li>All Business Features</li>
              <li>AI Threat Recognition</li>
              <li>Custom Rules</li>
              <li>Advanced Logs</li>
            </ul>
            <button className="buy-btn">Select Pro</button>
          </div>
        </div>
        <button className="close-btn" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}